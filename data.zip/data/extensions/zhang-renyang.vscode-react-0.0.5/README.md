## React Official Website VS Code Extension
- This is a VS Code extension designed for quick access to the React official website https://react.dev/.
- Please hold down the `Ctrl` key when clicking any button, as this will open the page in the default browser, and you can proceed with subsequent actions.


## React 官网 VS Code 插件
- 这是一个为快速访问React 官网 https://react.dev/ 设计的 VS Code 插件
- 点击任何按钮的时候请按住`ctrl`键，这将会在默认浏览器中打开页面，进行后续操作即可