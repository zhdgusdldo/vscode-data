## MIT License

(C) [2023] [zhangrenyang]

The permission granted by this license allows users to use and copy the software, as long as the following conditions are met:

## Conditions
The above copyright notice and this license notice must be included in all copies of the software and its documentation.

The software is for educational and non-commercial use only, and may not be sold or used in any way to generate commercial profits.

Unless required by applicable law or agreed to in writing, the software is provided "as is," without warranties of any kind, either express or implied, including but not limited to the implied warranties of merchantability and fitness for a particular purpose. The author or copyright holder will not be liable for any claims, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.

## Author
The author of this project is [zhangrenyang].

## Original Work
This extension is based on the React official website and is owned by the React official website.




