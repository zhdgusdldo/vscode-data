# Change Log
All notable changes to the "dotenv" extension will be documented in this file.

## 1.1.0
### Added
- [#2](https://github.com/mikestead/vscode-dotenv/issues/2) Added support for more .env file extensions

## 1.0.0
### Added
- Bundling https://github.com/zaynali53/DotENV for vscode extension